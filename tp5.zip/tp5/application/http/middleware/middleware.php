<?php
  return [
    'CheckToken'	=>	app\http\middleware\CheckToken::class
  ];