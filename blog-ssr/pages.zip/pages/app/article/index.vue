<template>
  <div class="about">
    Art
  </div>
</template>

<script>

export default {
  name: 'Art'
}
</script>
