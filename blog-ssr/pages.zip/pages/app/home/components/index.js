export { default as NewArt } from './NewArt.vue'
export { default as About } from './About.vue'
export { default as Navig } from './Navig.vue'
