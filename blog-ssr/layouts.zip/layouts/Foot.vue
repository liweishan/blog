<template>
  <div class="foot">
    <p>Copyright All Rights Reserved V.1.0.0 备案号:</p>
  </div>
</template>

<style lang="less" scoped>
.foot {
  background: #000;
  padding: 10px 0;
  position: relative;
  z-index: 2;
  p {
    margin: 0;
    color: #666;
    text-align: center;
  }
}
</style>
